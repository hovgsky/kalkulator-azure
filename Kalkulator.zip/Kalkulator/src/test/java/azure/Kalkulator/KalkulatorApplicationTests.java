package azure.Kalkulator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KalkulatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
